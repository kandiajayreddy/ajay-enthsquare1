var productData = [
    {
        "product_category": "kitchen",
        "product_name": "4-Piece Set Bamboo Table Matt"
    },
    {
        "product_category": "kitchen",
        "product_name": "Expresso Coffee Maker"
    },
    {
        "product_category": "shoes",
        "product_name": "Puma Trainers x3"
    },
    {
        "product_category": "home",
        "product_name": "4x6 Photo Frame"
    },
    {
        "product_category": "shoes",
        "product_name": "Skechers ProWalkers"
    },
    {
        "product_category": "home",
        "product_name": "Shower Curtain"
    },
    {
        "product_category": "home",
        "product_name": "Accent Table Lamp"
    },
    {
        "product_category": "electronics",
        "product_name": "Cannon x930 DSLR Camera"
    },
    {
        "product_category": "kitchen",
        "product_name": "12 Qt Pressure Cooker"
    },
    {
        "product_category": "electronics",
        "product_name": "Apple Iphone 8"
    },
    {
        "product_category": "kitchen",
        "product_name": "Wooden Hexagonal Coasters"
    },
    {
        "product_category": "electronics",
        "product_name": "Bose QC 300 Headphones"
    },
    {
        "product_category": "shoes",
        "product_name": "Reebok Classic 1990"
    },
    {
        "product_category": "kitchen",
        "product_name": "12-Piece Knife Set"
    },
    {
        "product_category": "shoes",
        "product_name": "Nike Air Max Elite"
    },
    {
        "product_category": "home",
        "product_name": "100% Cotton Towels"
    },
    {
        "product_category": "electronics",
        "product_name": "Sony Super Bass Earbuds"
    },
    {
        "product_category": "shoes",
        "product_name": "Addidas Foamfits"
    }
];


function populateProductCategoryList() {


    console.log('data---', productData);

    var productCategoryList = {};

    productData.forEach((product) => {
        if (productCategoryList.hasOwnProperty(product.product_category)) {
            productCategoryList[product.product_category].push(product);
        } else {
            productCategoryList[product.product_category] = [product];
        }
    });
    console.log(productCategoryList);
    var categoryList = '';
    Object.keys(productCategoryList).forEach((category) => {
        categoryList += `<li class="categoryListItems" item-type="${category}">${category}</li>`
    });
    document.getElementById("category_list").innerHTML = categoryList;

    console.log(document.getElementsByClassName('categoryListItems'));
    var categoryListItems = document.getElementsByClassName('categoryListItems');
    for (var i = 0; i < categoryListItems.length; i++) {
        console.log(categoryListItems[i])
        categoryListItems[i].addEventListener('click', (evt) => {
            console.log('asdasd', evt.target.getAttribute('item-type'));
            populateProductListItem(productCategoryList[evt.target.getAttribute('item-type')]);
        })
    }


}



function populateProductListItem(currentProductItems) {
    var productList = '';
    currentProductItems.forEach((pList) => {
        productList += `<li>${pList.product_name}</li>`
    });
    document.getElementById("product_list").innerHTML = productList;
}

window.onload = function () {
    populateProductCategoryList();
}